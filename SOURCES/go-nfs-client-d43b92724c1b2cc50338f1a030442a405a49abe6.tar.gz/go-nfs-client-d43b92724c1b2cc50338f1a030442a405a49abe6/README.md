NFS Client for Golang
=====================

[![godoc](http://godoc.org/github.com/fdawg4l/nfs?status.svg)](http://godoc.org/github.com/fdawg4l/nfs)

This is forked from and builds upon the work done [here](https://github.com/davecheney/nfs) which was put in the [public domain](https://github.com/davecheney/nfs/issues/1#issuecomment-280563247).

The objective is to build a minimal NFSv3 client.
