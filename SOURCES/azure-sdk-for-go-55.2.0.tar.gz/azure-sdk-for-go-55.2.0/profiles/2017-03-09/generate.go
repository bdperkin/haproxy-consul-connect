// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

package v20170309

//go:generate go run ../../tools/profileBuilder/main.go list --clear-output --input ./definition.json --name 2017-03-09 --output-location ./
