# tcpproxy

For library usage, see https://godoc.org/inet.af/tcpproxy/

For CLI usage, see https://github.com/inetaf/tcpproxy/blob/master/cmd/tlsrouter/README.md
