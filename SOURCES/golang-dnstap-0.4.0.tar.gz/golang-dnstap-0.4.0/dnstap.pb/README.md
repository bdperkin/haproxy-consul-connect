# dnstap: flexible, structured event replication format for DNS software

This directory contains only the protobuf schemas for [dnstap](http://dnstap.info/), and is the root of
a repository named "dnstap.pb".

See the following repositories/links for implementations:
- [golang-dnstap](https://github.com/dnstap/golang-dnstap): command-line tool and Golang package

# Community

There is a [mailing list](http://lists.redbarn.org/mailman/listinfo/dnstap) for everyone interested in discussing `dnstap`.
