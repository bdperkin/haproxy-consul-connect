//Library that uses Readability-like heuristics to extract text from an HTML document
package sandblast
