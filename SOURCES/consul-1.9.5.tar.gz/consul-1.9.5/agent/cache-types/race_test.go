// +build race

package cachetype

const testingRace = true
