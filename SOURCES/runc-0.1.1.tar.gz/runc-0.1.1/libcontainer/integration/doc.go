// integration is used for integration testing of libcontainer
package integration
