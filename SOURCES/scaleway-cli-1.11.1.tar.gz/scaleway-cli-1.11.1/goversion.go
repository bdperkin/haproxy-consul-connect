// +build go1.5

package goversion
