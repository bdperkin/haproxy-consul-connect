// +build !amd64

package ascii
