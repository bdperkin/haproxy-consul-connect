This example demonstrates a metrics export pipeline that supports
Prometheus (pull) and simultaneously exports OTLP to an OpenTelemetry
endpoint (push).
