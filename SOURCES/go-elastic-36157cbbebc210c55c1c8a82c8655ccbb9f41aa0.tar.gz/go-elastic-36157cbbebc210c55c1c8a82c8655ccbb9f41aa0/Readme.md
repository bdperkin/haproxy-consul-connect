
# go-elastic

  Little (incomplete) Elasticsearch client with AWS sigv4 support.

## Badges

[![GoDoc](https://godoc.org/github.com/tj/go-elastic?status.svg)](https://godoc.org/github.com/tj/go-elastic)
![](https://img.shields.io/badge/license-MIT-blue.svg)
![](https://img.shields.io/badge/status-stable-green.svg)
[![](http://apex.sh/images/badge.svg)](https://apex.sh/ping/)

---

> [tjholowaychuk.com](http://tjholowaychuk.com) &nbsp;&middot;&nbsp;
> GitHub [@tj](https://github.com/tj) &nbsp;&middot;&nbsp;
> Twitter [@tjholowaychuk](https://twitter.com/tjholowaychuk)
