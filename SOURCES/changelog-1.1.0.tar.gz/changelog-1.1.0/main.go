package main

import "github.com/influxdata/changelog/cmd"

func main() {
	cmd.Execute()
}
