// +build go1.2

package gcfg

import (
	"encoding"
)

type textUnmarshaler encoding.TextUnmarshaler
