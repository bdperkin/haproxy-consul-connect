---
title: Contributing
---

This page will eventually have information for those who want to contribute
to the project.

Also check the [CONTRIBUTING.md](https://github.com/goreleaser/goreleaser/blob/master/CONTRIBUTING.md)
file on the root of our repository.
