---
title: CGO
---

If you need to cross-compile with CGO enabled, our Docker image is not
supported and your config will not look that "clean", unfortunately.

You can check [this cookbook](/cookbooks/cgo-and-crosscompiling) for an
example.

You can also see the discussion about CGO in
[this issue](https://github.com/goreleaser/goreleaser/issues/708).

