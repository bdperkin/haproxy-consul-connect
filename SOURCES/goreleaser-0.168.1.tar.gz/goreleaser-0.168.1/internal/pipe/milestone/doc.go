// Package milestone implements Pipe and manages VCS milestones.
package milestone
