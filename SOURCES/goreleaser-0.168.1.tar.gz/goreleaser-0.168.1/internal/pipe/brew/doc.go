// Package brew implements the Pipe, providing formula generation and
// uploading it to a configured repo.
package brew
