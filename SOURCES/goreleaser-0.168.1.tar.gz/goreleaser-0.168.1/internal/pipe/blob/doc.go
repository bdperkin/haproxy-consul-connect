// Package blob provides a Pipe that push artifacts to blob supported by Go CDK
//
// TODO: replace current s3 implementation with this one.
package blob
