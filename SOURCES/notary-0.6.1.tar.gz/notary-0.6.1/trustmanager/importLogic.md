###This document is intended as an overview of the logic we use for importing keys

# A flowchart to detail the logic of our import function in `utils/keys.go` (`func ImportKeys`)

![alt text](http://i.imgur.com/HQICWeO.png "Flowchart of key import logic")

### Should this logic change, you can edit this image at `https://www.draw.io/i/HQICWeO`

