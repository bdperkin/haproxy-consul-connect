// +build !linux

package main

func protect() error {
	return nil
}
