// +build !race

package cachetype

const testingRace = false
