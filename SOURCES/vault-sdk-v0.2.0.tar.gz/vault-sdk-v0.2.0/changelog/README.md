# changelog

This folder holds changelog updates from commit 3bc7d15 onwards. See [hashicorp/go-changelog](https://github.com/hashicorp/go-changelog) for full documentation on the supported entries.
