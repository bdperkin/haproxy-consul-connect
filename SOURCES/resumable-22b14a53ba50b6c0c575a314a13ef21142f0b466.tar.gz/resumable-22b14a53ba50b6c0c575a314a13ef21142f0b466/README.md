__DEPRECATED__: This package is now deprecated. Just use the `crypto/sha256` 
package in the standard library. See an example in the 
[tests](https://golang.org/src/crypto/sha256/sha256_test.go#L140).

# resumable
A Subset of the Go `crypto` Package with a Resumable Hash Interface

### Documentation

GoDocs: http://godoc.org/github.com/stevvooe/resumable
