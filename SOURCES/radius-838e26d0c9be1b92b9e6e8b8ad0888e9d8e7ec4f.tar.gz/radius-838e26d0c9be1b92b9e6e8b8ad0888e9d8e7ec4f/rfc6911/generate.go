//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc6911 -output generated.go dictionary.rfc6911

package rfc6911
