//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc3162 -output generated.go dictionary.rfc3162

package rfc3162
