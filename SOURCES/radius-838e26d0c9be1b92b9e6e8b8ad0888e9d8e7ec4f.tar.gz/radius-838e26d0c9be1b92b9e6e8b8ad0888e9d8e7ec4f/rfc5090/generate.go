//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc5090 -output generated.go dictionary.rfc5090

package rfc5090
