//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc7268 -output generated.go dictionary.rfc7268

package rfc7268
