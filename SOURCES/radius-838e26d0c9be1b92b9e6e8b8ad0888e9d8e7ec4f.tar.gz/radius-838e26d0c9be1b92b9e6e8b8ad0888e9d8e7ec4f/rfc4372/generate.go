//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc4372 -output generated.go -ref Error-Cause:layeh.com/radius/rfc3576 dictionary.rfc4372

package rfc4372
