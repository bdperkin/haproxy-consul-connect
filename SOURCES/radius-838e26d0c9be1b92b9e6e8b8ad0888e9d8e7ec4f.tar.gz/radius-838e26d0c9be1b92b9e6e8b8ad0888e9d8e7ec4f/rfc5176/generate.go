//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc5176 -output generated.go -ref Error-Cause:layeh.com/radius/rfc3576 dictionary.rfc5176

package rfc5176
