//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc5580 -output generated.go dictionary.rfc5580

package rfc5580
