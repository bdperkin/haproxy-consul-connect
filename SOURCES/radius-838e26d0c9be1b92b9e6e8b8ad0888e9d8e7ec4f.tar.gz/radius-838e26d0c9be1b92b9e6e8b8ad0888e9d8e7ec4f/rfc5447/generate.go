//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc5447 -output generated.go dictionary.rfc5447

package rfc5447
