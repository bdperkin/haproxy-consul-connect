//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc4675 -output generated.go dictionary.rfc4675

package rfc4675
