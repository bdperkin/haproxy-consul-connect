//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc4072 -output generated.go dictionary.rfc4072

package rfc4072
