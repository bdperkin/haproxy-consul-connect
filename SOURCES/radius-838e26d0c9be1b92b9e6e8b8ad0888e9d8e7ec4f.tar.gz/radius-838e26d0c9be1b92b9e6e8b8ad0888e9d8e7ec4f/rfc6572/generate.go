//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc6572 -output generated.go -ignore PMIP6-Home-IPv4-HoA -ignore PMIP6-Visited-IPv4-HoA dictionary.rfc6572

package rfc6572
