//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc5607 -output generated.go -ref Service-Type:layeh.com/radius/rfc2865 dictionary.rfc5607

package rfc5607
