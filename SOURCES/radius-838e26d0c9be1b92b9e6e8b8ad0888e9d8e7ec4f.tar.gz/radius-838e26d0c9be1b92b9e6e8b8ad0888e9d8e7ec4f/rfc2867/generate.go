//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc2867 -output generated.go -ref Acct-Status-Type:layeh.com/radius/rfc2866 dictionary.rfc2867

package rfc2867
