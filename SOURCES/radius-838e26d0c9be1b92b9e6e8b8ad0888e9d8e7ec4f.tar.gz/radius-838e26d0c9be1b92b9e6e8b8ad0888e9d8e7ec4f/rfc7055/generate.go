//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc7055 -output generated.go dictionary.rfc7055

package rfc7055
