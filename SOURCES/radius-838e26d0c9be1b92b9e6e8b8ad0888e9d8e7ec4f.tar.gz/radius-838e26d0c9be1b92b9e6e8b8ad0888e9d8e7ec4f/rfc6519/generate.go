//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc6519 -output generated.go dictionary.rfc6519

package rfc6519
