//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc4603 -output generated.go -ref NAS-Port-Type:layeh.com/radius/rfc2865 dictionary.rfc4603

package rfc4603
