//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc5904 -output generated.go dictionary.rfc5904

package rfc5904
