// Package debug contains utilities for debugging RADIUS packets.
//
// API is currently unstable.
package debug
