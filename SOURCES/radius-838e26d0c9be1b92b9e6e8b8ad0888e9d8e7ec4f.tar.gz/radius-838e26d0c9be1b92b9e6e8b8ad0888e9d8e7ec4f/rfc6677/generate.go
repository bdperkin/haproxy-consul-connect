//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc6677 -output generated.go dictionary.rfc6677

package rfc6677
