//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc3576 -output generated.go -ref Service-Type:layeh.com/radius/rfc2865 dictionary.rfc3576

package rfc3576
