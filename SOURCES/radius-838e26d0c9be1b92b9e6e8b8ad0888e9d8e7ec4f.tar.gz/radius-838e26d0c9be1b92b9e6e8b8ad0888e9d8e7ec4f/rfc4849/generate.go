//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc4849 -output generated.go dictionary.rfc4849

package rfc4849
