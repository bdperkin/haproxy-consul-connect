//go:generate go run ../../cmd/radius-dict-gen/main.go -package saltencrypttest -output generated.go dictionary.saltencrypt

package saltencrypttest
