//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc4818 -output generated.go dictionary.rfc4818

package rfc4818
