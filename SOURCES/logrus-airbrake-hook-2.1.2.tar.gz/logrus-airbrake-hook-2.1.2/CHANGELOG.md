# logrus-airbrake-hook Changelog

V2.1.2 - 2017-06-01

* Update import logrus path (see https://github.com/sirupsen/logrus/pull/384)

v2.1.1 - 2016-09-22

* Fix request deletion from the log entry

v2.1.0 - 2016-09-22

* Support ***`*http.Request` error reporting

v2.0.0 - 2015-10-05

* Support gobrake v2 api

