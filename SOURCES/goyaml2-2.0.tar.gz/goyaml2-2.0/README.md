goyaml2
=======

YAML for Golang