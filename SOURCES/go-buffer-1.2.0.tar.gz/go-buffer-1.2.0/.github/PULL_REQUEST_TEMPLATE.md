Please open an issue and discuss changes before spending time on them, unless the change is trivial or an issue already exists.
