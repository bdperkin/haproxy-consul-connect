
v1.2.0 / 2020-08-06
===================

  * change DefaultFlushInterval to 30s

v1.1.0 / 2020-08-03
===================

  * add Buffer.FlushSync() for synchronous flushing
