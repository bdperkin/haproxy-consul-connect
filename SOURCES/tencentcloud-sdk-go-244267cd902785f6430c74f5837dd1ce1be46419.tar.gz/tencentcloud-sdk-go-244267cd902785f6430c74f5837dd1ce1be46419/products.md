| 包名 | 产品中文名 | 更新时间 |
|-|-|-|
| aa | [活动防刷](https://cloud.tencent.com/document/product/1189) | 2021-03-01 08:00:50 |
| aai | [](https://cloud.tencent.com/document/product) | 2019-08-08 23:15:13 |
| af | [借贷反欺诈](https://cloud.tencent.com/document/product/668) | 2021-01-07 08:00:37 |
| afc | [定制建模](https://cloud.tencent.com/document/product/1029) | 2021-01-07 08:00:36 |
| ame | [正版曲库直通车](https://cloud.tencent.com/document/product/1155) | 2021-05-31 08:10:00 |
| ams | [音频内容检测](https://cloud.tencent.com/document/product/1219) | 2021-05-12 08:01:04 |
| apcas | [汽车精准获客服务](https://cloud.tencent.com/document/product/1244) | 2021-03-30 08:00:17 |
| ape | [正版图库直通车](https://cloud.tencent.com/document/product/1181) | 2021-04-20 08:00:30 |
| api | [云 API](https://cloud.tencent.com/document/product/546) | 2021-04-25 10:09:57 |
| apigateway | [API网关](https://cloud.tencent.com/document/product/628) | 2021-05-14 08:10:21 |
| as | [弹性伸缩](https://cloud.tencent.com/document/product/377) | 2021-06-01 08:03:00 |
| asr | [语音识别](https://cloud.tencent.com/document/product/1093) | 2021-05-14 08:00:43 |
| asw | [应用与服务编排工作流](https://cloud.tencent.com/document/product/1272) | 2021-04-02 08:00:26 |
| ba | [网站备案](https://cloud.tencent.com/document/product/243) | 2021-01-07 08:00:11 |
| batch | [批量计算](https://cloud.tencent.com/document/product/599) | 2021-02-24 08:01:57 |
| bda | [人体分析](https://cloud.tencent.com/document/product/1208) | 2021-05-14 08:01:08 |
| billing | [计费相关](https://cloud.tencent.com/document/product/555) | 2021-04-16 08:02:23 |
| bizlive | [商业直播](https://cloud.tencent.com/document/product) | 2020-03-10 01:08:07 |
| bm | [黑石物理服务器1.0](https://cloud.tencent.com/document/product/386) | 2021-04-01 08:02:25 |
| bmeip | [黑石弹性公网IP](https://cloud.tencent.com/document/product/1028) | 2021-04-23 08:02:32 |
| bmlb | [黑石负载均衡](https://cloud.tencent.com/document/product/1027) | 2021-01-07 08:02:27 |
| bmvpc | [黑石私有网络](https://cloud.tencent.com/document/product/1024) | 2021-01-07 08:02:33 |
| bri | [业务风险情报](https://cloud.tencent.com/document/product/1064) | 2021-01-07 08:02:40 |
| btoe | [区块链可信取证](https://cloud.tencent.com/document/product/1259) | 2021-04-21 17:20:24 |
| cam | [访问管理](https://cloud.tencent.com/document/product/598) | 2021-04-23 08:02:51 |
| captcha | [验证码](https://cloud.tencent.com/document/product/1110) | 2021-03-22 08:03:03 |
| cat | [云拨测](https://cloud.tencent.com/document/product/280) | 2021-01-07 08:01:42 |
| cbs | [云硬盘](https://cloud.tencent.com/document/product/362) | 2021-05-21 08:03:17 |
| ccc | [云呼叫中心](https://cloud.tencent.com/document/product/679) | 2021-04-07 08:00:41 |
| cdb | [云数据库 MySQL](https://cloud.tencent.com/document/product/236) | 2021-05-28 08:03:30 |
| cdn | [内容分发网络](https://cloud.tencent.com/document/product/228) | 2021-05-11 08:03:44 |
| cds | [数据安全审计](https://cloud.tencent.com/document/product/856) | 2021-01-07 08:03:25 |
| cfs | [文件存储](https://cloud.tencent.com/document/product/582) | 2021-04-07 08:03:25 |
| cfw | [云防火墙](https://cloud.tencent.com/document/product/1132) | 2021-05-14 08:11:06 |
| chdfs | [云 HDFS](https://cloud.tencent.com/document/product/1105) | 2021-02-22 08:03:09 |
| cii | [智能保险助手](https://cloud.tencent.com/document/product/1368) | 2021-05-08 15:29:47 |
| cim | [](https://cloud.tencent.com/document/product) | 2019-05-16 17:21:18 |
| cis | [](https://cloud.tencent.com/document/product) | 2018-06-07 15:01:42 |
| ckafka | [消息队列 Ckafka](https://cloud.tencent.com/document/product/597) | 2021-05-17 08:10:03 |
| clb | [负载均衡](https://cloud.tencent.com/document/product/214) | 2021-05-31 08:04:01 |
| cloudaudit | [云审计](https://cloud.tencent.com/document/product/629) | 2021-05-26 08:10:55 |
| cloudhsm | [云加密机](https://cloud.tencent.com/document/product/639) | 2021-05-28 08:09:58 |
| cls | [日志服务](https://cloud.tencent.com/document/product/614) | 2021-05-31 17:22:23 |
| cme | [腾讯云剪](https://cloud.tencent.com/document/product/1156) | 2021-05-26 08:02:29 |
| cmq | [消息队列 CMQ](https://cloud.tencent.com/document/product/406) | 2021-02-22 08:01:08 |
| cms | [内容安全](https://cloud.tencent.com/document/product) | 2020-10-29 08:03:08 |
| cpdp | [企业收付平台](https://cloud.tencent.com/document/product/1122) | 2021-05-28 20:59:36 |
| cr | [金融联络机器人](https://cloud.tencent.com/document/product/656) | 2021-02-24 08:03:24 |
| cvm | [云服务器](https://cloud.tencent.com/document/product/213) | 2021-05-27 08:04:09 |
| cwp | [主机安全](https://cloud.tencent.com/document/product/296) | 2021-06-01 08:12:13 |
| cws | [漏洞扫描服务](https://cloud.tencent.com/document/product) | 2019-11-22 12:16:15 |
| cynosdb | [云数据库 CynosDB](https://cloud.tencent.com/document/product/1003) | 2021-05-31 08:01:04 |
| dayu | [DDoS 高防包](https://cloud.tencent.com/document/product/1021) | 2021-04-26 08:04:08 |
| dbbrain | [数据库智能管家 DBbrain](https://cloud.tencent.com/document/product/1130) | 2021-05-28 08:04:39 |
| dc | [专线接入](https://cloud.tencent.com/document/product/216) | 2021-05-24 08:04:38 |
| dcdb | [分布式数据库 TDSQL](https://cloud.tencent.com/document/product/557) | 2021-06-01 08:05:28 |
| dlc | [数据湖计算](https://cloud.tencent.com/document/product/1342) | 2021-03-26 08:00:05 |
| dnspod | [DNSPod](https://cloud.tencent.com/document/product/1427) | 2021-05-31 08:00:07 |
| domain | [域名注册](https://cloud.tencent.com/document/product/242) | 2021-05-31 08:04:49 |
| drm | [数字版权管理](https://cloud.tencent.com/document/product/1000) | 2021-01-07 08:04:33 |
| ds | [电子合同服务](https://cloud.tencent.com/document/product/869) | 2021-01-07 08:04:34 |
| dts | [数据传输服务](https://cloud.tencent.com/document/product/571) | 2021-02-03 08:04:31 |
| ecc | [英文作文批改](https://cloud.tencent.com/document/product/1076) | 2021-01-07 08:04:40 |
| ecdn | [全站加速网络](https://cloud.tencent.com/document/product/570) | 2021-05-28 08:01:48 |
| ecm | [边缘计算机器](https://cloud.tencent.com/document/product/1108) | 2021-05-28 08:01:24 |
| eis | [企业集成服务](https://cloud.tencent.com/document/product/1270) | 2021-05-26 08:00:07 |
| emr | [弹性 MapReduce](https://cloud.tencent.com/document/product/589) | 2021-05-28 08:05:02 |
| es | [Elasticsearch Service](https://cloud.tencent.com/document/product/845) | 2021-05-11 08:05:19 |
| facefusion | [人脸融合](https://cloud.tencent.com/document/product/670) | 2021-05-07 08:04:04 |
| faceid | [人脸核身](https://cloud.tencent.com/document/product/1007) | 2021-05-26 08:05:08 |
| fmu | [人脸试妆](https://cloud.tencent.com/document/product/1172) | 2021-03-16 08:02:03 |
| ft | [人像变换](https://cloud.tencent.com/document/product/1202) | 2021-04-12 08:01:48 |
| gaap | [全球应用加速](https://cloud.tencent.com/document/product/608) | 2021-03-24 08:05:04 |
| gme | [游戏多媒体引擎](https://cloud.tencent.com/document/product/607) | 2021-04-20 08:05:33 |
| gpm | [游戏玩家匹配](https://cloud.tencent.com/document/product/1294) | 2021-04-28 08:00:58 |
| gs | [云游戏解决方案](https://cloud.tencent.com/document/product/1162) | 2021-04-13 08:02:06 |
| gse | [游戏服务器伸缩](https://cloud.tencent.com/document/product/1165) | 2021-05-13 08:01:51 |
| habo | [](https://cloud.tencent.com/document/product) | 2019-05-09 19:37:22 |
| hcm | [数学作业批改](https://cloud.tencent.com/document/product/1004) | 2021-02-03 08:05:01 |
| iai | [人脸识别](https://cloud.tencent.com/document/product/867) | 2021-05-26 08:05:27 |
| ic | [物联卡](https://cloud.tencent.com/document/product/636) | 2021-05-11 20:09:52 |
| ie | [智能编辑](https://cloud.tencent.com/document/product/1186) | 2021-05-13 08:01:13 |
| iir | [智能识图](https://cloud.tencent.com/document/product/1217) | 2021-01-07 08:00:40 |
| ims | [图片内容检测](https://cloud.tencent.com/document/product/1125) | 2021-05-12 08:00:38 |
| iot | [加速物联网套件](https://cloud.tencent.com/document/product/568) | 2021-01-07 08:05:22 |
| iotcloud | [物联网通信](https://cloud.tencent.com/document/product/634) | 2021-05-31 08:05:42 |
| iotexplorer | [物联网开发平台](https://cloud.tencent.com/document/product/1081) | 2021-05-31 08:05:55 |
| iottid | [物联网设备身份认证](https://cloud.tencent.com/document/product/1086) | 2021-01-07 08:05:49 |
| iotvideo | [物联网智能视频服务](https://cloud.tencent.com/document/product/1131) | 2021-06-01 08:02:14 |
| iotvideoindustry | [物联网智能视频服务（行业版）](https://cloud.tencent.com/document/product/1361) | 2021-05-08 15:18:48 |
| kms | [密钥管理系统](https://cloud.tencent.com/document/product/573) | 2021-05-25 08:06:56 |
| lighthouse | [轻量应用服务器](https://cloud.tencent.com/document/product/1207) | 2021-05-11 08:00:57 |
| live | [云直播](https://cloud.tencent.com/document/product/267) | 2021-05-25 08:07:04 |
| lp | [登录保护](https://cloud.tencent.com/document/product/1190) | 2021-01-07 08:00:37 |
| mariadb | [云数据库 MariaDB](https://cloud.tencent.com/document/product/237) | 2021-06-01 08:07:15 |
| memcached | [云数据库 Memcached](https://cloud.tencent.com/document/product) | 2020-08-24 08:07:49 |
| mgobe | [游戏联机对战引擎](https://cloud.tencent.com/document/product/1038) | 2021-01-26 08:00:28 |
| mna | [移动网络加速](https://cloud.tencent.com/document/product/1385) | 2021-05-17 08:00:05 |
| mongodb | [云数据库 MongoDB](https://cloud.tencent.com/document/product/240) | 2021-05-27 08:06:27 |
| monitor | [云监控](https://cloud.tencent.com/document/product/248) | 2021-05-31 08:06:37 |
| mps | [视频处理](https://cloud.tencent.com/document/product/862) | 2021-05-21 08:06:33 |
| mrs | [医疗报告结构化](https://cloud.tencent.com/document/product/1314) | 2021-05-25 08:00:05 |
| ms | [移动应用安全](https://cloud.tencent.com/document/product) | 2020-06-05 08:13:52 |
| msp | [迁移服务平台](https://cloud.tencent.com/document/product/659) | 2021-01-07 08:06:57 |
| mvj | [营销价值判断](https://cloud.tencent.com/document/product) | 2020-03-19 08:11:44 |
| nlp | [自然语言处理](https://cloud.tencent.com/document/product/271) | 2021-05-10 16:12:19 |
| npp | [号码保护](https://cloud.tencent.com/document/product) | 2020-04-22 08:00:22 |
| oceanus | [流计算 Oceanus](https://cloud.tencent.com/document/product/849) | 2021-05-17 08:00:28 |
| ocr | [文字识别](https://cloud.tencent.com/document/product/866) | 2021-06-01 08:07:57 |
| organization | [企业组织](https://cloud.tencent.com/document/product/850) | 2021-03-31 08:06:30 |
| partners | [渠道合作伙伴](https://cloud.tencent.com/document/product/563) | 2021-05-20 08:06:59 |
| postgres | [云数据库 PostgreSQL](https://cloud.tencent.com/document/product/409) | 2021-05-28 08:07:07 |
| privatedns | [私有域解析 Private DNS](https://cloud.tencent.com/document/product/1338) | 2021-06-01 08:00:27 |
| rce | [全栈式风控引擎](https://cloud.tencent.com/document/product/1343) | 2021-05-08 15:29:43 |
| redis | [云数据库 Redis](https://cloud.tencent.com/document/product/239) | 2021-05-17 08:07:21 |
| rkp | [风险探针](https://cloud.tencent.com/document/product/1169) | 2021-01-07 08:11:09 |
| rp | [注册保护](https://cloud.tencent.com/document/product/1191) | 2021-01-07 08:00:38 |
| scf | [云函数](https://cloud.tencent.com/document/product/583) | 2021-05-31 08:07:35 |
| ses | [邮件推送](https://cloud.tencent.com/document/product/1288) | 2021-05-13 08:10:37 |
| smpn | [营销号码安全](https://cloud.tencent.com/document/product/1127) | 2021-01-07 08:01:56 |
| sms | [短信](https://cloud.tencent.com/document/product/382) | 2021-05-18 14:31:03 |
| soe | [智聆口语评测](https://cloud.tencent.com/document/product/884) | 2021-06-01 08:08:42 |
| solar | [智汇零售](https://cloud.tencent.com/document/product) | 2020-03-19 08:01:59 |
| sqlserver | [云数据库 SQL Server](https://cloud.tencent.com/document/product/238) | 2021-03-10 08:08:58 |
| ssa | [态势感知](https://cloud.tencent.com/document/product/664) | 2021-01-14 08:00:06 |
| ssl | [证书](https://cloud.tencent.com/document/product/400) | 2021-04-05 08:01:51 |
| sslpod | [SSL 证书监控](https://cloud.tencent.com/document/product/1084) | 2021-01-07 08:00:15 |
| ssm | [凭据管理系统](https://cloud.tencent.com/document/product/1140) | 2021-01-07 08:01:49 |
| sts | [安全凭证服务](https://cloud.tencent.com/document/product/1312) | 2021-05-17 08:10:58 |
| taf | [流量反欺诈](https://cloud.tencent.com/document/product/1031) | 2021-04-29 08:00:57 |
| tag | [标签](https://cloud.tencent.com/document/product/651) | 2021-01-26 08:07:51 |
| tat | [腾讯云自动化助手](https://cloud.tencent.com/document/product/1340) | 2021-05-31 08:11:21 |
| tav | [文件检测](https://cloud.tencent.com/document/product) | 2019-11-28 22:10:04 |
| tbaas | [TBaaS](https://cloud.tencent.com/document/product/663) | 2021-03-18 08:07:48 |
| tbm | [](https://cloud.tencent.com/document/product) | 2019-03-29 14:49:11 |
| tbp | [腾讯智能对话平台](https://cloud.tencent.com/document/product/1060) | 2021-01-07 08:07:55 |
| tcaplusdb | [游戏数据库 TcaplusDB](https://cloud.tencent.com/document/product/596) | 2021-05-20 08:07:49 |
| tcb | [云开发 CloudBase](https://cloud.tencent.com/document/product/876) | 2021-06-01 08:09:10 |
| tcex | [腾讯云释义](https://cloud.tencent.com/document/product/1266) | 2021-01-07 08:00:18 |
| tci | [腾讯智学课堂分析](https://cloud.tencent.com/document/product) | 2020-08-24 08:06:03 |
| tcr | [容器镜像服务](https://cloud.tencent.com/document/product/1141) | 2021-05-17 08:10:10 |
| tdmq | [分布式消息队列](https://cloud.tencent.com/document/product/1179) | 2021-05-18 08:11:59 |
| tem | [弹性微服务](https://cloud.tencent.com/document/product/1371) | 2021-05-17 08:00:12 |
| tia | [智能钛机器学习](https://cloud.tencent.com/document/product) | 2020-03-16 08:18:42 |
| tic | [腾讯云IaC平台](https://cloud.tencent.com/document/product/1213) | 2021-01-07 08:00:07 |
| ticm | [智能鉴黄](https://cloud.tencent.com/document/product/864) | 2021-01-07 08:08:15 |
| tics | [威胁情报云查服务](https://cloud.tencent.com/document/product/1013) | 2021-01-07 08:08:14 |
| tiems | [智能钛弹性模型服务](https://cloud.tencent.com/document/product/1120) | 2021-01-07 08:08:16 |
| tiia | [图像分析](https://cloud.tencent.com/document/product/865) | 2021-01-07 08:08:12 |
| tione | [智能钛机器学习平台](https://cloud.tencent.com/document/product/851) | 2021-01-07 08:01:07 |
| tiw | [互动白板](https://cloud.tencent.com/document/product/1137) | 2021-05-18 08:11:02 |
| tke | [容器服务](https://cloud.tencent.com/document/product/457) | 2021-05-28 08:08:07 |
| tkgdq | [腾讯知识图谱数据查询](https://cloud.tencent.com/document/product) | 2020-03-10 00:51:44 |
| tms | [文本内容安全](https://cloud.tencent.com/document/product/1124) | 2021-01-28 08:00:40 |
| tmt | [机器翻译](https://cloud.tencent.com/document/product/551) | 2021-01-07 08:08:32 |
| trtc | [实时音视频](https://cloud.tencent.com/document/product/647) | 2021-05-27 08:09:49 |
| tse | [腾讯云微服务引擎](https://cloud.tencent.com/document/product/1364) | 2021-05-25 08:00:36 |
| tsf | [腾讯微服务平台 TSF](https://cloud.tencent.com/document/product/649) | 2021-05-27 08:08:28 |
| tsw | [腾讯微服务观测平台 TSW](https://cloud.tencent.com/document/product/1311) | 2021-04-30 08:10:47 |
| tts | [语音合成](https://cloud.tencent.com/document/product/1073) | 2021-02-26 08:08:15 |
| ump | [客流数字化平台](https://cloud.tencent.com/document/product/1320) | 2021-03-11 08:00:14 |
| vm | [视频内容安全](https://cloud.tencent.com/document/product/1265) | 2021-04-21 08:00:21 |
| vms | [语音消息](https://cloud.tencent.com/document/product/1128) | 2021-04-28 08:00:35 |
| vod | [云点播](https://cloud.tencent.com/document/product/266) | 2021-05-31 08:09:28 |
| vpc | [私有网络](https://cloud.tencent.com/document/product/215) | 2021-06-01 08:10:06 |
| waf | [Web 应用防火墙](https://cloud.tencent.com/document/product/627) | 2021-04-28 08:14:06 |
| wss | [SSL证书管理服务](https://cloud.tencent.com/document/product) | 2020-04-01 08:53:44 |
| youmall | [](https://cloud.tencent.com/document/product) | 2019-01-11 11:24:15 |
| yunjing | [主机安全](https://cloud.tencent.com/document/product) | 2020-09-15 08:08:47 |
| yunsou | [腾讯云搜](https://cloud.tencent.com/document/product/270) | 2021-01-07 08:09:58 |
| zj | [珠玑](https://cloud.tencent.com/document/product) | 2020-11-17 08:10:59 |