// Package rethinkdb-go implements a Go driver for RethinkDB
//
// Current version: v3.0.2 (RethinkDB v2.3)
// For more in depth information on how to use RethinkDB check out the API docs
// at http://rethinkdb.com/api
package rethinkdb
