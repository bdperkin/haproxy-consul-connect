# go-trees [![Build Status](https://travis-ci.org/infobloxopen/go-trees.svg?branch=master)](https://travis-ci.org/infobloxopen/go-trees.svg?branch=master)&nbsp;[![GoDoc](https://godoc.org/github.com/infobloxopen/go-trees?status.svg)](https://godoc.org/github.com/infobloxopen/go-trees)&nbsp;[![Go Report Card](https://goreportcard.com/badge/github.com/infobloxopen/go-trees)](https://goreportcard.com/report/github.com/infobloxopen/go-trees)

go packages for radix and other trees
