
[![GoDoc](https://godoc.org/github.com/tj/go-kinesis?status.svg)](https://godoc.org/github.com/tj/go-kinesis)

# go-kinesis

Batch producer for Kinesis built on top of the official Go AWS SDK.

# License

MIT