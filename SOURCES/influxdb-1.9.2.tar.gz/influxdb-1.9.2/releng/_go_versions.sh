# This file is meant to be sourced from other scripts.

export GO_CURRENT_VERSION=1.15.10
