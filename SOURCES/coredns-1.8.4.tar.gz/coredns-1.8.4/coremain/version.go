package coremain

// Various CoreDNS constants.
const (
	CoreVersion = "1.8.4"
	coreName    = "CoreDNS"
	serverType  = "dns"
)
