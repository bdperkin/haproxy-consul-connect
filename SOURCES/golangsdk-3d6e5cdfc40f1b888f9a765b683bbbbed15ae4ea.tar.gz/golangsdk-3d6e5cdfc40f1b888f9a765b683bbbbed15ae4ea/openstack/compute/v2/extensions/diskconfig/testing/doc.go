// diskconfig unit tests
package testing
