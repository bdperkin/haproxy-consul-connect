## nightly
* Added support for ignoring fields.

## v1.1.0

* Added support for recursive data structures.
* Fixed bug with embedded fixed length arrays in structs.
* Added `example/` directory.
* Minor test bug fixes for future go versions.
* Added change log.

## v1.0.0

Initial tagged release release.
