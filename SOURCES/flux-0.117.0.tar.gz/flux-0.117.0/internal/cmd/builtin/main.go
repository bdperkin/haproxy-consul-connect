package main

import "github.com/influxdata/flux/internal/cmd/builtin/cmd"

func main() {
	cmd.Execute()
}
