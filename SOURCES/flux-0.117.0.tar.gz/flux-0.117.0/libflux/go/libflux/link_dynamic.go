// +build !static_build

package libflux

// #cgo pkg-config: flux
import "C"
