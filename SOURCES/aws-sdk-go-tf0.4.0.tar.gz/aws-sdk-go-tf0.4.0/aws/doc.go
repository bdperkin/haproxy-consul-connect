// Package aws contains support code for the various AWS clients in the
// github.com/hashicorp/aws-sdk-go/gen subpackages.
package aws
