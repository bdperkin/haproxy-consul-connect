#ifndef TABLEFLUX_DRIVER_H
#define TABLEFLUX_DRIVER_H

extern int tableflux_call( const char *tableflux, char **out_flux,
		char **out_err, char **out_log );

#endif

