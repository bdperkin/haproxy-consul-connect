// Package asttest implements utilities for testing the abstract syntax tree.
package asttest
