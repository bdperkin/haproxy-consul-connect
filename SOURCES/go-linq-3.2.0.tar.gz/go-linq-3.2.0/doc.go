// Package linq provides methods for querying and manipulating slices, arrays,
// maps, strings, channels and collections.
//
// Authors: Alexander Kalankhodzhaev (kalan), Ahmet Alp Balkan, Cleiton Marques
// Souza.
package linq
