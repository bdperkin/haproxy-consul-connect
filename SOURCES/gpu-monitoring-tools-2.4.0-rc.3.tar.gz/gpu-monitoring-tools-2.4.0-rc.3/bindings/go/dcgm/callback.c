int violationNotify(void* p) {
    int ViolationRegistration(void*);
    return ViolationRegistration(p);
}
