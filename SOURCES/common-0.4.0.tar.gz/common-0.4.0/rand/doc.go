// A library based on crypto/rand to create random sequences
package rand
