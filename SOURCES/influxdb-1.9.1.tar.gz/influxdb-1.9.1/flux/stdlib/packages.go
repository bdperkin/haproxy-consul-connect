package stdlib

// Import all stdlib packages
import (
	_ "github.com/influxdata/influxdb/flux/stdlib/influxdata/influxdb"
	_ "github.com/influxdata/influxdb/flux/stdlib/influxdata/influxdb/v1"
)
