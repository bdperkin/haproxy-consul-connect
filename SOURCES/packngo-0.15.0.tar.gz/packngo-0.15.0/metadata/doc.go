// Package metadata implements the Equinix Metal Metadata API available
// to Equinix Metal devices at https://metadata.platformequinix.com/metadata.
//
// For more information, see
// https://metal.equinix.com/developers/docs/servers/metadata/
package metadata
