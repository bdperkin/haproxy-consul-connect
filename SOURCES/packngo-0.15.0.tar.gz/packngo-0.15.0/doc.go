// Package packngo implements the Equinix Metal API
// documented at https://metal.equinix.com/developers/api.
package packngo
