// go get -u github.com/tencentcloud/tencentcloud-sdk-go
// package github.com/tencentcloud/tencentcloud-sdk-go: no Go files in /Users/xxx/go/src/github.com/tencentcloud/tencentcloud-sdk-go
// FIXME: this is a workaround for above go get issue, a fake file does nothing but claims we are a go project.
// Eventually we need something useful here, such as real documentation, version and etc.
package doc
