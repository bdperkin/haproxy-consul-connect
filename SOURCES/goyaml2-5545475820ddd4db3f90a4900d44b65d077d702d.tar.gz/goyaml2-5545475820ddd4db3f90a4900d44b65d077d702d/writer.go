package goyaml2

import (
	"io"
)

func Write(w io.Writer, v interface{}) error {
	return nil
}
