// Package windows contains various Windows system call.
package windows
