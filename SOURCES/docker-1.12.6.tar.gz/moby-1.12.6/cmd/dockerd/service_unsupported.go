// +build !windows

package main

func initService() (bool, error) {
	return false, nil
}
