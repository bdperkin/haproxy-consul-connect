package container

const (
	testAbsPath = `c:\foo`
)
