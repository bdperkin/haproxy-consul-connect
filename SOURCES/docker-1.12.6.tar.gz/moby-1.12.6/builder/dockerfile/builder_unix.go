// +build !windows

package dockerfile

var defaultShell = []string{"/bin/sh", "-c"}
