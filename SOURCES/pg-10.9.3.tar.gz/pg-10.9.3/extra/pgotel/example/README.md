# OpenTelemetry instrumentation for go-pg

To run this example you need a PostgreSQL server. You can start one with Docker:

```bash
make up
```

Then run the example:

```bash
go run main.go
```
