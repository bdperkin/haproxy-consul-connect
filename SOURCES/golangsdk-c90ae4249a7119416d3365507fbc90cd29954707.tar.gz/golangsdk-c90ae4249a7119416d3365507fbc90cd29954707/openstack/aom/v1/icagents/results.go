package icagents

import (
	"github.com/huaweicloud/golangsdk"
)

type commonResult struct {
	golangsdk.Result
}
type CreateResult struct {
	commonResult
}
