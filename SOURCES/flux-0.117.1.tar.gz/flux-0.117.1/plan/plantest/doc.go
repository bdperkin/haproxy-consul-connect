// Package plantest contains utilities for testing each query planning phase
package plantest
