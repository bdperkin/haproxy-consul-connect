package plan_test

import (
	// We need to init flux for the tests to work.
	_ "github.com/influxdata/flux/fluxinit/static"
)
