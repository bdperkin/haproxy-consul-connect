package table

import "github.com/influxdata/flux/execute/table"

type Iterator = table.Iterator
