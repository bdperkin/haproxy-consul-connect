// Package arp implements the ARP protocol, as described in RFC 826.
package arp
