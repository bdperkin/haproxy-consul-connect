package pkg

func (t9) fn2() {} // used
