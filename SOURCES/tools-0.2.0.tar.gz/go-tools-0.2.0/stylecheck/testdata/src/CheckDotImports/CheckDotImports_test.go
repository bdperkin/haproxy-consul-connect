package pkg

import . "fmt"

var _ = Println
