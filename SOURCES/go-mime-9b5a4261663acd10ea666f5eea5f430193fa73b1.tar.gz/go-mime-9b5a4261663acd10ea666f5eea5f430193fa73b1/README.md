# Go Mime Wrapper Library

## Download/Install

Run `go get -u github.com/ProtonMail/go-mime`, or manually `git clone` the
repository into `$GOPATH/src/github.com/ProtonMail/go-mime`.
