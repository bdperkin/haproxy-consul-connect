package mount // import "github.com/ory/dockertest/docker/pkg/mount"

func parseMountTable() ([]*Info, error) {
	// Do NOT return an error!
	return nil, nil
}
