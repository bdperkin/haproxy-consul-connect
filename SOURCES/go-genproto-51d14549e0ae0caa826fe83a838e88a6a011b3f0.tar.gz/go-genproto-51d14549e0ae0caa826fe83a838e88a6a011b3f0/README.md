# Go generated proto packages

This repository contains the generated Go packages for Yandex.Cloud API.
