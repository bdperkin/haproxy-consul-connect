---
name: "\U0001F917 Question"
about: Ask a question so we can help
title: "\U0001F917 "
labels: 'Type: Question'
assignees: ''

---

**Question description**

**Code snippet** _Optional_

```go
package main

import "github.com/gofiber/fiber/v2"

func main() {
  app := fiber.New()
  // ..
}
```
