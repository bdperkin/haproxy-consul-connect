## Authors

* John Jeffery
* Hiram Jerónimo Pérez
* Alessandro Siragusa
* DaytonG
* Erik Benoist
* Evan Borgstrom
* Fernando Ribeiro
* Fredrik Rubensson
* Laurent Luce
* Oliver, Jonathan
* Paul P. Komkoff
* Raphael Tiersch
* Tom Lee
* Tony Le
* Voronkov Artem
* Whit Marbut
* hanjm
* yang.zhang4
