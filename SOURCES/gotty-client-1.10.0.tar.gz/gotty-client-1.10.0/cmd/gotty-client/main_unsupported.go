// +build !go1.11

package main

func error() {
	`Bad go version, please install a version greater than or equal to 1.11`
}
