package elastigo

import (
	"errors"
)

// 404 Response.
var RecordNotFound = errors.New("record not found")
