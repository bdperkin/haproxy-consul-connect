#!/bin/bash

echo "Ok" > /tmp/posttrans-proof
