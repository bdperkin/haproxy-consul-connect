#!/bin/sh

echo "Ok" > /tmp/preupgrade-proof
