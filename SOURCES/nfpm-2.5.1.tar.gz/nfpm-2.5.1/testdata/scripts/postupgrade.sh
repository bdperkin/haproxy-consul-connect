#!/bin/sh

echo "$@"

echo "PostUpgrade" > /dev/null
