#!/bin/bash

echo "Pretrans" > /dev/null
