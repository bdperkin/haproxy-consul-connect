#!/bin/bash

echo "Postinstall" > /dev/null
