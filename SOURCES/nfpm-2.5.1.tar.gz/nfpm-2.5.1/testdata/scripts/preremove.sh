#!/bin/bash

echo "Preremove" > /dev/null
