# Cross-compiling Go with CGO

Best option to cross-compile Go project with CGO dependencies would be in using docker image.
[This project](https://github.com/troian/golang-cross) provides the [image](https://hub.docker.com/repository/docker/troian/golang-cross) with bunch of ready to use cross-compilers as well as how-to make sysroot.
All that wrapped into [example](https://github.com/troian/golang-cross-example)
