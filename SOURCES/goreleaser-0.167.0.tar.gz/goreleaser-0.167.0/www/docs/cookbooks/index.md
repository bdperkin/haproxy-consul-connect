# Cookbooks

The idea here is to add examples of how to do specific things with GoReleaser.

Feel free to [contribute yours](/cookbooks/contributing/)!
