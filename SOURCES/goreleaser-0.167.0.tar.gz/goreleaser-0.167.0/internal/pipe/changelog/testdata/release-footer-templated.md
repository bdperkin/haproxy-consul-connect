test footer with tag {{ .Tag }}
