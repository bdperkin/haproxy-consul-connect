test header with tag {{ .Tag }}
