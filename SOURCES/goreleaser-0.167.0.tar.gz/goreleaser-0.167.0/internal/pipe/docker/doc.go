// Package docker provides a Pipe that creates and pushes Docker images and
// manifests.
package docker
