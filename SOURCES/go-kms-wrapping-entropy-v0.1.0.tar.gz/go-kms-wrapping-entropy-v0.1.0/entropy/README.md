# Entropy Package

This package is split into its own Go module so that importers just wanting
entropy do not need the full set of dependencies used by the main module.
