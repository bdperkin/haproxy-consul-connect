# Contributors

This is the official list of people who can contribute (and typically
have contributed) to the repository.

The 'AUTHORS' file lists the copyright holders; this file lists people. For
example, the employees of an organization are listed here but not in 'AUTHORS',
because the organization holds the copyright.

Names should be added to this file as:

    Name <email address> / (url address)

Please keep the list sorted.

## Code

* Jonas mg (https://github.com/tredoe)