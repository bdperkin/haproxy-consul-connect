# Authors

This is the official list of authors for copyright purposes.
This file is distinct from the 'CONTRIBUTORS' file. See the latter for an explanation.

Names should be added to this file as:

    Name or Organization <email address> / (url address)

(The email address is not required for organizations)

Please keep the list sorted.

## Code

* Jonas mg (https://github.com/tredoe)